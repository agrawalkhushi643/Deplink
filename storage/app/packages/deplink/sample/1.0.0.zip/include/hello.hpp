#pragma once

extern "C" void sayHello(const char* name);
